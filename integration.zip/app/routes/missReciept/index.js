
const salasaConnector = require('../../api/order/salasa');
const miscReciept = require('../../api/order/miscReciept');
const { getAdminEnvSettings, extractOccEnvironment } = require('../../api/order/environmentSettings');
const { missingRequiredInformationError, unableToProcessError, successResponse } = require('./response');



async function missReciept(req, res) {
  const payload = req.body;
  
  let connector = new miscReciept(getAdminEnvSettings(extractOccEnvironment(req.get('host')))); 
  const sendOrder = await connector.sendMiscReciept(payload);
  console.log(
    `[orderConnector] Sending back HTTP 200: ${JSON.stringify(
      sendOrder,
      null,
      2
    )}`
  );
  res.status(200).json({"erpOrderId":sendOrder});
}

module.exports = missReciept;