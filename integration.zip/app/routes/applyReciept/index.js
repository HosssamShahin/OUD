const salasaConnector = require('../../api/order/salasa');
const fusionConnector = require('../../api/order/fusion');
const {
  getAdminEnvSettings,
  extractOccEnvironment
} = require('../../api/order/environmentSettings');
const {
  missingRequiredInformationError,
  unableToProcessError,
  successResponse
} = require('./response');



async function reciept(req, res) {
  const payload = req.body;

  console.log(`[orderConnector] Inside OMS Connector`);

  let responseData = {};
  var axios = require('axios');
  var data = JSON.stringify(payload
  );

  var config = {
    method: 'post',
    url: 'https://egrc-test.fa.us2.oraclecloud.com:443/fscmRestApi/resources/11.13.18.05/standardReceipts',
    headers: {
      'Authorization': 'Basic YW1yX21hbnNvdXJAcmF5YWlzLmNvbTpSYXlhMTIzNA==',
      'Content-Type': 'application/json',
      'Cookie': 'ak_bmsc=C96231B896D109CE1C2449D5C07285FC~000000000000000000000000000000~YAAQVzZ8aFvabWp9AQAASTmncQ19qG5xzFFTQj+rhhKtcGO9SYPH58sEOqCMWin6Pv98XYnYaRbF9+8LV+/LhBWnIhe9iLVE9tR9m7nZzfm0U2kgcZXbeLYt0yIo+vxpmiF5lAyChxxIxJ//1CAI/xdZOEAv09yMFEi626HIDujLKLjVS1Q7fkjtMdoh1Tual2rr7DlUF2h1wqB8uzO2qQn0gCBR5JRJtmR0mfhKT+S/lS/NJOv63WSj0EEI5trGC8Bg49g1BSebay6tBrVTlPJYJgWjz7MvE9bbk+THd1H1+JxZFrbLryO2UHIPK5Ww2A9JyLJ6wLHauhMADZSGPoHCvCeKlKQFrSOOsxhD7Bv4asTxITegWQVm6PeGObXLU/sB23ZJfA=='
    },
    data: data
  };

  await axios(config)
    .then(function (response) {
      console.log(JSON.stringify(response.data));
      responseData = response.data;
    })
    .catch(function (error) {
      console.log(error);
    });



  res.status(200).json(responseData);



}

module.exports = reciept;