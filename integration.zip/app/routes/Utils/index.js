const utilsConnector = require('../../api/order/utils');
const { getAdminEnvSettings, extractOccEnvironment } = require('../../api/order/environmentSettings');
const { missingRequiredInformationError, unableToProcessError, successResponse } = require('./response');



async function fulfillOrder(req, res) {
  
  const payload = req.body;
  let connector = new utilsConnector(getAdminEnvSettings(extractOccEnvironment(req.get('host')))); 
  const sendOrder = await connector.fulfillOrder(payload.id);



      res.status(200).json("Order is Fullfilled");
      
    }
    

   

module.exports = fulfillOrder;