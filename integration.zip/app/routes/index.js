const order = require('./Order');
const fulfillOrder = require('./Utils');
const returnOrder = require('./returns')
const reciept = require('./applyReciept')
const miscIssue = require('./miscIssue')
const arInvoice = require('./arInvoice')
const miscReciept = require('./missReciept')
module.exports = app => {
  app.post('/v1/processOrder', order);
  app.post('/v1/fulfillOrder',fulfillOrder);
  app.post('/v1/returnOrder',returnOrder);
  app.post('/v1/reciept',reciept);
  app.post('/v1/miscIssue',miscIssue);
  app.post('/v1/arInvoice',arInvoice);
  app.post('/v1/miscReciept',miscReciept);
};