
const salasaConnector = require('../../api/order/salasa');
  const arInvoiceConnector = require('../../api/order/arInvoice');
const { getAdminEnvSettings, extractOccEnvironment } = require('../../api/order/environmentSettings');
const { missingRequiredInformationError, unableToProcessError, successResponse } = require('./response');



async function arInvoice(req, res) {
  const payload = req.body;
  
  let connector = new arInvoiceConnector(getAdminEnvSettings(extractOccEnvironment(req.get('host')))); 
  const sendOrder = await connector.sendARInvoice(payload);
  console.log(
    `[orderConnector] Sending back HTTP 200: ${JSON.stringify(
      sendOrder,
      null,
      2
    )}`
  );
  res.status(200).json({"erpOrderId":sendOrder});
}

module.exports = arInvoice;