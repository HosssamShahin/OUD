
const salasaConnector = require('../../api/order/salasa');
const fusionConnector = require('../../api/order/fusion');
const { getAdminEnvSettings, extractOccEnvironment } = require('../../api/order/environmentSettings');
const { missingRequiredInformationError, unableToProcessError, successResponse } = require('./response');



async function Return(req, res) {
  const payload = req.body;
  
    console.log(`[orderConnector] Inside Returns Connector`);
    const carrier =  payload.carrier ;
  
    if(carrier === 'salasa') {
      let connector = new salasaConnector(getAdminEnvSettings(extractOccEnvironment(req.get('host')))); 
      const returnOrder = await connector.returnOrderToSalasa(payload);
      console.log(
        `[orderConnector] Sending back HTTP 200: ${JSON.stringify(
          returnOrder,
          null,
          2
        )}`
      );
      res.status(200).json(returnOrder);
      
    }else {

      let connector = new fusionConnector(getAdminEnvSettings(extractOccEnvironment(req.get('host')))); 
      const sendOrder = await connector.returnOrderToFusion(payload);
      console.log(
        `[orderConnector] Sending back HTTP 200: ${JSON.stringify(
          sendOrder,
          null,
          2
        )}`
      );
      res.status(200).json(sendOrder); 

    }
    

   /* let connector = new orderConnector(getAdminEnvSettings(extractOccEnvironment(req.get('host')))); 
    
  try{
    const updateOrder = await connector.updateOrder(payload);
    console.log(
      `[orderConnector] Sending back HTTP 200: ${JSON.stringify(
        updateOrder,
        null,
        2
      )}`
    );

    console.log(updateOrder);
    res.status(200).json(updateOrder);
  }catch (e) {
    console.log(`[orderConnector] Got an error while updating order. Sending back HTTP 400`);
    res.status(400).json(unableToProcessError(e));
  } */
}

module.exports = Return;