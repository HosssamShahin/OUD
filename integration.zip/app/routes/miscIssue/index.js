
const miscIssueConnector = require('../../api/order/miscIssue');
  const fusionConnector = require('../../api/order/fusion');
const { getAdminEnvSettings, extractOccEnvironment } = require('../../api/order/environmentSettings');
const { missingRequiredInformationError, unableToProcessError, successResponse } = require('./response');



async function miscIssue(req, res) {
  const payload = req.body;
  
    console.log(`[orderConnector] Inside OMS Connector`);
    
      let connector = new miscIssueConnector(getAdminEnvSettings(extractOccEnvironment(req.get('host')))); 
      const sendOrder = await connector.sendMiscIssue(payload);
      console.log(
        `[orderConnector] Sending back HTTP 200: ${JSON.stringify(
          sendOrder,
          null,
          2
        )}`
      );
      res.status(200).json({"erpOrderId":sendOrder});
      

}

module.exports = miscIssue;