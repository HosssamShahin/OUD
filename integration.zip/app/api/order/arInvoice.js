const querystring = require("querystring");
const parser = require('fast-xml-parser');
const he = require('he');
const request = require('request');

class arInvoice {
  constructor(options) {
    this.host_name = options.admin_url;
    this.api_key = options.api_key;
  }

  async sendARInvoice(pPayload) {
    console.log("Inside Return To Fusion : START");
    const order=  await this.getOCCOrder(pPayload.orderId);
    console.log(order);
    const soapRequest = require('easy-soap-request');
    const fs = require('fs');
    //var  fusionOrderId = order.erp_orderId;
    let orderResp;

    var itemXML = '';
    for(var i=0 ;i<order.commerceItems.length ;i++) {


      const payload =  `<inv:InvoiceLine>
               <inv:LineNumber>${i+1}</inv:LineNumber>
               <inv:Description>Ecommerce Invoice</inv:Description>
               <inv:Quantity>${order.commerceItems[i].quantity}</inv:Quantity>
               <inv:ItemNumber>${order.commerceItems[i].catalogRefId}</inv:ItemNumber>
               
               <inv:UnitSellingPrice currencyCode="SAR">${(order.commerceItems[i].priceInfo.salePrice)}</inv:UnitSellingPrice>
          </inv:InvoiceLine>`;

      
      itemXML =itemXML +payload;

    }
    

    const url = 'https://egrc-test.fa.us2.oraclecloud.com//fscmService/RecInvoiceService';
    const sampleHeaders = {
      'user-agent': 'sampleTest',
      'Authorization': 'Basic YW1yX21hbnNvdXJAcmF5YWlzLmNvbTpSYXlhMTIzNA==',
      'Content-Type': 'text/xml;charset=UTF-8',
      'soapAction': 'https://egrc-test.fa.us2.oraclecloud.com:443/fscmService/RecInvoiceService',
    };



 const xml = `<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:typ="http://xmlns.oracle.com/apps/financials/receivables/transactions/invoices/invoiceService/types/" xmlns:inv="http://xmlns.oracle.com/apps/financials/receivables/transactions/invoices/invoiceService/" xmlns:tran="http://xmlns.oracle.com/apps/financials/receivables/transactions/shared/model/flex/TransactionLineDff/" xmlns:tran1="http://xmlns.oracle.com/apps/financials/receivables/transactions/shared/model/flex/TransactionHeaderDff/" xmlns:tran2="http://xmlns.oracle.com/apps/financials/receivables/transactions/shared/model/flex/TransactionInterfaceHeaderDff/" xmlns:tran3="http://xmlns.oracle.com/apps/financials/receivables/transactions/shared/model/flex/TransactionHeaderGdf/">
 <soapenv:Header/>
 <soapenv:Body>
    <typ:createSimpleInvoice>
       <typ:invoiceHeaderInformation>
          <inv:BusinessUnit>Oud Milano - Saudi Arabia</inv:BusinessUnit>
          <inv:TransactionSource>OUD Imported TRX</inv:TransactionSource>
          <inv:TransactionType>IN-102004</inv:TransactionType>
          <inv:TrxNumber>${order.id}</inv:TrxNumber>
          <inv:TrxDate>${new Date().toJSON().slice(0,10)}</inv:TrxDate>
          <inv:BillToAccountNumber>5</inv:BillToAccountNumber>
          <inv:PaymentTermsName>IMMEDIATE</inv:PaymentTermsName>
          <inv:InvoiceCurrencyCode>SAR</inv:InvoiceCurrencyCode>
          <inv:PurchaseOrder>${order.id}</inv:PurchaseOrder>
          ${itemXML}
       </typ:invoiceHeaderInformation>
    </typ:createSimpleInvoice>
 </soapenv:Body>
</soapenv:Envelope>`;



    // usage of module


    try {
      const {
        response
      } = await soapRequest({
        url: url,
        headers: sampleHeaders,
        xml: xml
      }); // Optional timeout parameter(milliseconds)
      const {
        headers,
        body,
        statusCode
      } = response;
      console.log("==================================");
      console.log(headers);
      console.log("==================================");

      var options = {
        attributeNamePrefix: "@_",
        attrNodeName: "attr", //default is 'false'
        textNodeName: "#text",
        ignoreAttributes: true,
        ignoreNameSpace: false,
        allowBooleanAttributes: false,
        parseNodeValue: true,
        parseAttributeValue: false,
        trimValues: true,
        cdataTagName: "__cdata", //default is 'false'
        cdataPositionChar: "\\c",
        parseTrueNumberOnly: false,
        arrayMode: false, //"strict"
        attrValueProcessor: (val, attrName) => he.decode(val, {
          isAttributeValue: true
        }), //default is a=>a
        tagValueProcessor: (val, tagName) => he.decode(val), //default is a=>a
        stopNodes: ["parse-me-as-string"]
      };
      let orderNumber;
      if (parser.validate(body) === true) { //optional (it'll return an object in case it's not valid)
        var jsonObj = parser.parse(body, options);
        console.log(jsonObj);
        
        orderResp = jsonObj;
      }

      console.log("==================================");
      console.log(statusCode);
    } catch (e) {
      const {
        headers,
        body,
        statusCode
      } = e;
      console.log(statusCode);
      console.error(e);
    }


    return orderResp;


    console.log("Inside Return To Fusion : END");
    return "1232";
  }


  async sendOrderToFusion(pPayload) {

    console.log("Inside Send To Fusion");

    const soapRequest = require('easy-soap-request');
    const fs = require('fs');
    let orderResp;
    let fusionCustomerName = pPayload.customerName;
    let fusionCustomerNo = pPayload.customerNo;
    let address1 = pPayload.shippingGroups[0].shippingAddress.address1 ? pPayload.shippingGroups[0].shippingAddress.address1 : ''; 
    let city = pPayload.shippingGroups[0].shippingAddress.city ? pPayload.shippingGroups[0].shippingAddress.city : ''; 
    let country = pPayload.shippingGroups[0].shippingAddress.country ? pPayload.shippingGroups[0].shippingAddress.country : ''; 
    let postalCode = pPayload.shippingGroups[0].shippingAddress.postalCode ? pPayload.shippingGroups[0].shippingAddress.postalCode : ''; 
    let shippingAddress = address1 + ',' + city + ',' + country + '' +postalCode ;
    let customerName =  pPayload.shippingGroups[0].shippingAddress.firstName + ' ' + pPayload.shippingGroups[0].shippingAddress.lastName;
    let ecommOrder = '';
    if(pPayload.paymentGroups[0].paymentMethod === 'onlinePaymentGroup') {
      ecommOrder = 'Online Payment';
    }else {
      ecommOrder = 'Cash on Delivery';
    }
    // example data
    const url = 'https://egrc-test.fa.us2.oraclecloud.com:443/fscmService/OrderImportService';
    const sampleHeaders = {
      'user-agent': 'sampleTest',
      'Authorization': 'Basic YW1yX21hbnNvdXJAcmF5YWlzLmNvbTpSYXlhMTIzNA==',
      'Content-Type': 'text/xml;charset=UTF-8',
      'soapAction': 'http://xmlns.oracle.com/apps/scm/fom/importOrders/orderImportService/createOrders',
    };

let itemXML = '';

    for (let i = 0; i < pPayload.commerceItems.length; i++) {
      const payload = `<ord:Line>

      <ord:RequestedFulfillmentOrganizationCode>KSA_DC_001</ord:RequestedFulfillmentOrganizationCode>

      <!--Optional:-->

      <ord:RequestedShipDate>2021-06-09T22:08:52</ord:RequestedShipDate>

      <ord:SourceTransactionLineIdentifier>${i+1}</ord:SourceTransactionLineIdentifier>

      <ord:SourceTransactionScheduleIdentifier>${i+1}</ord:SourceTransactionScheduleIdentifier>

      <ord:SourceTransactionLineNumber>${i+1}</ord:SourceTransactionLineNumber>

      <ord:SourceTransactionScheduleNumber>${i+1}</ord:SourceTransactionScheduleNumber>


      <ord:ProductNumber>${pPayload.commerceItems[i].catalogRefId}</ord:ProductNumber>

      <ord:InventoryOrganizationIdentifier>300000001716247</ord:InventoryOrganizationIdentifier>

      <ord:OrderedQuantity>${pPayload.commerceItems[i].quantity}</ord:OrderedQuantity>

      <ord:ProductType>GOODS</ord:ProductType>

      <ord:TransactionBusinessCategory>SALES_TRANSACTION</ord:TransactionBusinessCategory>

      <ord:OrderedUOMCode>zzy</ord:OrderedUOMCode>

      <ord:RequestingBusinessUnitIdentifier>300000001709520</ord:RequestingBusinessUnitIdentifier>

      <ord:PaymentTerms>IMMEDIATE</ord:PaymentTerms>

      <ord:PackingInstructions>Standard</ord:PackingInstructions>

      <ord:TransactionCategoryCode>ORDER</ord:TransactionCategoryCode>

      <ord:ShipToPartyType>ORGANIZATION</ord:ShipToPartyType>

      <ord:ShipToPartyIdentifier>300000001773047</ord:ShipToPartyIdentifier>

      <ord:ShipToPartySiteIdentifier>300000001773051</ord:ShipToPartySiteIdentifier>

      <ord:BillToPartyType>ORGANIZATION</ord:BillToPartyType>

      <ord:BillToCustomerIdentifier>300000001773049</ord:BillToCustomerIdentifier>

      <ord:BillToAccountSiteUseIdentifier>300000001773053</ord:BillToAccountSiteUseIdentifier>

      <ord:PartialShipAllowedFlag>false</ord:PartialShipAllowedFlag>

      <ord:UnitListPrice>300.0</ord:UnitListPrice>

      <ord:UnitSellingPrice>300.00</ord:UnitSellingPrice>

      <ord:ExtendedAmount>300.00</ord:ExtendedAmount>

      <ord:TaxExempt>S</ord:TaxExempt>

      <ord:OrigSystemDocumentReference>ORIGSYS</ord:OrigSystemDocumentReference>

      <ord:OrigSystemDocumentLineReference>ORIGSYSLINE</ord:OrigSystemDocumentLineReference>

      <ord:ManualPriceAdjustment>
      <ord:ChargeDefinitionCode>QP_SALE_PRICE</ord:ChargeDefinitionCode>
      <ord:AdjustmentAmount>${pPayload.commerceItems[i].priceInfo.salePrice}</ord:AdjustmentAmount>
      <ord:Reason>Other</ord:Reason>
      <ord:AdjustmentType>Price override</ord:AdjustmentType>
      <ord:ChargeRollupFlag>false</ord:ChargeRollupFlag>
      <ord:SourceManualPriceAdjustmentIdentifier>${i+1}</ord:SourceManualPriceAdjustmentIdentifier>
      <ord:SequenceNumber>${i+1}</ord:SequenceNumber>
      <ord:ValidationStatusCode>NOT_STARTED</ord:ValidationStatusCode>
   </ord:ManualPriceAdjustment>

   </ord:Line>` ;
      itemXML =itemXML +payload;

    }

    const xml = `<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:typ="http://xmlns.oracle.com/apps/scm/fom/importOrders/orderImportService/types/" xmlns:ord="http://xmlns.oracle.com/apps/scm/fom/importOrders/orderImportService/" xmlns:mod="http://xmlns.oracle.com/apps/scm/doo/processOrder/model/" xmlns:xsi="xsi">

    <soapenv:Header/>
 
    <soapenv:Body>
 
       <typ:createOrdersAsync>
 
          <typ:request>
 
             <!--Optional:-->
 
             <ord:BatchName/>
 
             <!--Zero or more repetitions:-->
 
             <ord:Order>
                <ord:SourceTransactionIdentifier>${pPayload.id}</ord:SourceTransactionIdentifier>
                <ord:SourceTransactionSystem>OPS</ord:SourceTransactionSystem>
                <ord:SourceTransactionNumber>${pPayload.id}</ord:SourceTransactionNumber>
                <ord:BuyingPartyType>ORGNIZATION</ord:BuyingPartyType>
                <ord:BuyingPartyId>300000001773047</ord:BuyingPartyId>
                <ord:TransactionTypeCode>001</ord:TransactionTypeCode>
                <ord:CustomerPONumber>${pPayload.id}</ord:CustomerPONumber>
                <ord:ShipToPartyType>ORGANIZATION</ord:ShipToPartyType>
                <ord:ShipToPartyIdentifier>300000001773047</ord:ShipToPartyIdentifier>
                <ord:ShipToPartySiteIdentifier>300000001773051</ord:ShipToPartySiteIdentifier>
                <ord:BillToPartyType>ORGANIZATION</ord:BillToPartyType>
                <ord:BillToCustomerIdentifier>300000001773049</ord:BillToCustomerIdentifier>
                <ord:BillToAccountSiteUseIdentifier>300000001773053</ord:BillToAccountSiteUseIdentifier>
                <ord:TransactionalCurrencyCode>SAR</ord:TransactionalCurrencyCode>
                <ord:TransactionOn>${pPayload.submittedDate}</ord:TransactionOn>
                <ord:RequestingBusinessUnitIdentifier>300000001709520</ord:RequestingBusinessUnitIdentifier>
                <ord:PartialShipAllowedFlag>false</ord:PartialShipAllowedFlag>
                <ord:FreezePriceFlag>False</ord:FreezePriceFlag>
                <ord:ShippingCarrier>Fedex</ord:ShippingCarrier>
                <ord:ShippingServiceLevel>2nd day air</ord:ShippingServiceLevel>
                <ord:ShippingMode>Air</ord:ShippingMode>
                ${itemXML}

                <ord:AdditionalHeaderInformationCategories xsi:type="ns12:j_HeaderEffDooHeadersAddInfoprivate" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:ns3="http://xmlns.oracle.com/apps/scm/doo/processOrder/service/" xmlns:ns12="http://xmlns.oracle.com/apps/scm/doo/processOrder/flex/headerCategories/" xmlns:ns22="http://xmlns.oracle.com/apps/scm/doo/processOrder/flex/headerContextsB/" xmlns:ns8="http://xmlns.oracle.com/apps/scm/doo/processOrder/model/">
                  <ns8:Category>DOO_HEADERS_ADD_INFO</ns8:Category>
                  <ns12:HeaderEffBCustomer__InformationprivateVO>
                     <ns8:ContextCode>Customer Information</ns8:ContextCode>
                     <ns22:customerName>${customerName}</ns22:customerName>
					 <ns22:customerPhone>${pPayload.shippingGroups[0].shippingAddress.phoneNumber}</ns22:customerPhone>
					 <ns22:customerAdress>${shippingAddress}</ns22:customerAdress>
					 <ns22:wayBill>wayBill</ns22:wayBill>
					 <ns22:ecomOrder>${ecommOrder}</ns22:ecomOrder>
                  </ns12:HeaderEffBCustomer__InformationprivateVO>
               </ord:AdditionalHeaderInformationCategories>
                
                <ord:OrderPreferences>
 
                   <!--Optional:-->
 
                   <ord:CreateCustomerInformationFlag>False</ord:CreateCustomerInformationFlag>
 
                   <!--Optional:-->
 
                   <ord:SubmitFlag>True</ord:SubmitFlag>
 
                </ord:OrderPreferences>
 
             </ord:Order>
 
          </typ:request>
 
       </typ:createOrdersAsync>
 
    </soapenv:Body>
 
 </soapenv:Envelope>`;

    // usage of module


    try {
      const {
        response
      } = await soapRequest({
        url: url,
        headers: sampleHeaders,
        xml: xml
      }); // Optional timeout parameter(milliseconds)
      const {
        headers,
        body,
        statusCode
      } = response;
      console.log("==================================");
      console.log(headers);
      console.log("==================================");

      var options = {
        attributeNamePrefix: "@_",
        attrNodeName: "attr", //default is 'false'
        textNodeName: "#text",
        ignoreAttributes: true,
        ignoreNameSpace: false,
        allowBooleanAttributes: false,
        parseNodeValue: true,
        parseAttributeValue: false,
        trimValues: true,
        cdataTagName: "__cdata", //default is 'false'
        cdataPositionChar: "\\c",
        parseTrueNumberOnly: false,
        arrayMode: false, //"strict"
        attrValueProcessor: (val, attrName) => he.decode(val, {
          isAttributeValue: true
        }), //default is a=>a
        tagValueProcessor: (val, tagName) => he.decode(val), //default is a=>a
        stopNodes: ["parse-me-as-string"]
      };
      let orderNumber;
      if (parser.validate(body) === true) { //optional (it'll return an object in case it's not valid)
        var jsonObj = parser.parse(body, options);
        console.log(jsonObj);
        console.log(jsonObj['env:Envelope']);
        const envelope = jsonObj['env:Envelope'];
        const bodyResp = envelope['env:Body'];
        const asynResp = bodyResp['ns0:createOrdersAsyncResponse'];
        const result = asynResp['ns1:result'];
        if(result['ns0:OrderNumber'] != '') {
          orderNumber = result['ns0:OrderNumber'];
        }
      }
      if(orderNumber !== '' && orderNumber) {
        await this.updateOrder(pPayload.cartName, orderNumber);
      }
     
      
      console.log(body);
      orderResp = orderNumber;
      console.log("==================================");
      console.log(statusCode);
    } catch (e) {
      const {
        headers,
        body,
        statusCode
      } = e;
      console.log(statusCode);
      console.error(e);
    }
   
  //  await this.waitforme(5000);
   

  return orderResp;

  }

  async waitforme(ms)  {
    return new Promise( resolve => { setTimeout(resolve, ms); });
  }

  async updateOrder(occOrderId, fusionOrderId) {
    const token = await this.retrieveToken();
    var orderState;
    var orderId = occOrderId;

    var axios = require('axios');
    var data = '';

    var config = {
      method: 'put',
      url: `${this.host_name}/ccadmin/v1/orders/${orderId}`,
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'X-CCAsset-Language': 'en',
        'Authorization': `Bearer ${token}`,
      },
      data: {
        erp_orderId: fusionOrderId.toString(),
        erp_name: "fusion",
        state: "PROCESSING",
      }
    };

    await axios(config)
      .then(function (response) {
        console.log(JSON.stringify(response.data));
      })
      .catch(function (error) {
        console.log(error);
      });



  }

  async returnDataOrder(occOrderId, fusionOrderId) {
    const token = await this.retrieveToken();
    var orderState;
    var orderId = occOrderId;

    var axios = require('axios');
    var data = '';

    var config = {
      method: 'put',
      url: `${this.host_name}/ccadmin/v1/orders/${orderId}`,
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'X-CCAsset-Language': 'en',
        'Authorization': `Bearer ${token}`,
      },
      data: {
        return_order_id: fusionOrderId.toString(),
        erp_name: "fusion",
        state : "PENDING_CUSTOMER_RETURN"
      }
    };

    await axios(config)
      .then(function (response) {
        console.log(JSON.stringify(response.data));
      })
      .catch(function (error) {
        console.log(error);
      });



  }


  async getOCCOrder(id) {
    const token = await this.retrieveToken();
    let orders ;
    try {
    

      var axios = require('axios');

      var config = {
        method: 'get',
        url: `${this.host_name}/ccadmin/v1/orders/${id}`,
        headers: {
          Authorization: `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      };
      
     await axios(config)
      .then(function (response) {
        console.log(JSON.stringify(response.data));
        orders = response.data;
      })
      .catch(function (error) {
        console.log(error);
      });
      

return orders;



    } catch (e) {
      console.log(`Cannot update order :  ${e}`);
      throw e;
    }
  }


  async getOrders(pPayload) {
    const token = await this.retrieveToken();
    var date = `date("${pPayload.date}")`;
    var state = "SUBMITTED";
    try {

      const orders = await request({
        headers: {
          Authorization: `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        url: `${this.host_name}/ccadmin/v1/orders?queryFormat=SCIM&q=state eq "PENDING_APPROVAL"`,
        method: 'GET',
        json: true
      });
      console.log(
        ` [Order] Sending back HTTP 200: ${JSON.stringify(orders,
          null,
          2
        )}`);

      return orders;
    } catch (e) {
      console.log(`Cannot update order :  ${e}`);
      throw e;
    }
  }

  /*
  This method would return access token based on the requesting enviroment .

  */
  async retrieveToken() {

    let loginResponse;

    var axios = require('axios');
    var qs = require('qs');
    var data = qs.stringify({
      'grant_type': 'client_credentials'
    });
    var config = {
      method: 'post',
      url: `${this.host_name}/ccadminui/v1/login`,
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'Authorization': `Bearer ${this.api_key}`,
      },
      data: data
    };

    await axios(config)
      .then(function (response) {
        loginResponse = response.data;
        //  console.log(JSON.stringify(response.data));
      })
      .catch(function (error) {
        console.log(error);
      });


    return loginResponse.access_token;

    /*try {
      loginResponse = await request({
        headers: {
          Authorization: `Bearer ${this.api_key}`,
          'Content-Type': 'application/x-www-form-urlencoded'
        },
        url: `${this.host_name}/ccadminui/v1/login`,
        method: 'POST',
        body: querystring.stringify({
          grant_type: 'client_credentials'
        }),
        json: true
      });
    } catch (e) {
      console.log(`Cannot get credentials. ${e}`);
      throw e;
    }
    return loginResponse.access_token;
    */
  }
}

module.exports = arInvoice;