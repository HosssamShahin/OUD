const environmentSettings = {
  prod: {
    admin_url :'https://ccadmin-test-zbqa.oracleoutsourcing.com',
    api_key: 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiI3NDM4NTNlYS05YmNkLTQ3YmYtYTYzYS0zZTc2YzBjZmZlNDYiLCJpc3MiOiJhcHBsaWNhdGlvbkF1dGgiLCJleHAiOjE2NDEzNTcyMTMsImlhdCI6MTYwOTgyMTIxM30=.jx0S6pNwldx+Ahl5bB0r+qooYT/2lbspD1ovvTXsIx8='
  },
  sandbox: {
    salasa_return_url: 'https://staging-salasa-api-public.eunimart.com/api/v2/order_management/whole_return/create',
    salasa_api_key : 'ODMwYThjOWYtODU3MC00MjFmLTk5ZGEtNWMyODBlNTE2OWIx',
    salasa_token : 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoiODMwYThjOWYtODU3MC00MjFmLTk5ZGEtNWMyODBlNTE2OWIxIiwidXNlcl9uYW1lIjoidGVzIiwiZW1haWxfaWQiOiJiaGF2aW4wN0B5bWFpbC5jb20iLCJmaXJzdF9uYW1lIjoidGVzIiwibGFzdF9uYW1lIjoidGVzIiwiYWNjb3VudF9pZCI6ImFkNzEwNzk2LWY4NjItNDFmNi04YzUwLWViMTVlYzA3M2QwOSIsImNsaWVudF9jb2RlIjoiVEVTVDEiLCJqdGkiOiI4OGM0ZGYxYy03ZGNmLTQxZjQtODA4ZC1jMjJhNzg2OTk3ZGUiLCJuZXdfdXNlciI6ZmFsc2UsImlhdCI6MTYyNDcxNDM2NiwiZXhwIjoxNjU2MjUwMzY2LCJhdWQiOiIweXAxNTd5bWQ0IiwiaXNzIjoidmRlemlfZGV2ZWxvcGVyX3NldHRpbmdzX21hbmFnZW1lbnQifQ.9NHnipkCvcQSUqnVyev1gefYRwTwbW_bzXeIgOXg34k',
    admin_url :'https://p1550825c1dev-admin.occa.ocs.oraclecloud.com',
    api_key: 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiI3NDM4NTNlYS05YmNkLTQ3YmYtYTYzYS0zZTc2YzBjZmZlNDYiLCJpc3MiOiJhcHBsaWNhdGlvbkF1dGgiLCJleHAiOjE2NDEzNTcyMTMsImlhdCI6MTYwOTgyMTIxM30=.jx0S6pNwldx+Ahl5bB0r+qooYT/2lbspD1ovvTXsIx8=',
    account_id : 'ad710796-f862-41f6-8c50-eb15ec073d09',
    token : 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoiMTBiMTQ2OTQtZTFhZC00MWQzLWJkMjMtOTFmNjhiYjMzNDI2IiwidXNlcl9uYW1lIjoiY2xvdWRpZnlhcHBzLmNvbSIsImVtYWlsX2lkIjoiYWRtaW5AY2xvdWRpZnlhcHBzLmNvbSIsImZpcnN0X25hbWUiOiJjbG91ZGlmeWFwcHMuY29tIiwibGFzdF9uYW1lIjoiY2xvdWRpZnlhcHBzLmNvbSIsImFjY291bnRfaWQiOiJhZDcxMDc5Ni1mODYyLTQxZjYtOGM1MC1lYjE1ZWMwNzNkMDkiLCJjbGllbnRfY29kZSI6IlRFU1QxIiwianRpIjoiYWNjOTcwNzMtOTA4OC00NDEyLWI3NzUtYzhiZjVkODBmZDU2IiwibmV3X3VzZXIiOmZhbHNlLCJpYXQiOjE2MjM4NTUyMTMsImV4cCI6MTY1NTM5MTIxMywiYXVkIjoiMHlwMTU3eW1kNCIsImlzcyI6InZkZXppX2RldmVsb3Blcl9zZXR0aW5nc19tYW5hZ2VtZW50In0.JB4IJV7921-izAH4aYnoRb3H0_h47SQtN-MUDUe0rW4',
    salasaHostname : 'https://staging-salasa-api-internal.eunimart.com'
  }
};

const environmentsMapping = {
  prod: 'prod',
  'localhost' :'sandbox',
  'ccadmin-test-zbqa':'sandobx',
  'ccadmin-test-zbqa': 'sandbox'
};

function getAdminEnvSettings(occEnvironment) {
  return environmentSettings[environmentsMapping['ccadmin-test-zbqa']];
}

function extractOccEnvironment(origin) {
  const regex = /(.*)\.(oracle|localhost)/;
  const match = regex.exec(origin);

  if (match && match[1]) {
    return match[1];
  }

  return '';
}

module.exports = {  getAdminEnvSettings, extractOccEnvironment };
