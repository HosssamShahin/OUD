const querystring = require("querystring");
const axios = require('axios');
const request = require('request');


class salasa {
  constructor(options) {
    this.host_name = options.admin_url;
    this.api_key = options.api_key;
    this.account_id = options.account_id;
    this.token = options.token;
    this.salasaHostname = options.salasaHostname;
    this.salasa_return_url = options.salasa_return_url;
    this.salasa_api_key = options.salasa_api_key;
    this.salasa_token = options.salasa_token;
  }



  async returnOrderToSalasa(pPayload) {
    console.log("::::::::RETURNS:::::");
    var self = this;
    const orderId= pPayload.orderId;
    const occOrderId = pPayload.occOrderId;
    const order = await this.getOrderfromSalasa(orderId);
    const returnRequst = await this.createReturn(order);
    const returnId = returnRequst.data.return_id;
    const orderItems = await this.getOrderItems(orderId);
    for (let i = 0; i < orderItems.data.length; i++) {
      await self.addItemsToReturn(orderItems.data[i], returnId);
    }
    await self.updateReturn(returnId);
    await self.completeReturn(returnId);
    await self.updateReturnOrder(occOrderId,returnId);

    return returnId;
  }

  async getOrderItems(pOrderId) {
    var resp;
    var config = {
      method: 'get',
      url: `https://staging-salasa-api-internal.eunimart.com/api/v2/order_management/order_item/list?order_id=${pOrderId}&pagination=0&account_id=ad710796-f862-41f6-8c50-eb15ec073d09`,
      headers: {
        'Authorization': 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoiMjFmYTI3YjctM2Y1Ni00MzJmLWIwNzItYWU4MmU1OGM4YWRlIiwiYWNjb3VudF9pZCI6ImFkNzEwNzk2LWY4NjItNDFmNi04YzUwLWViMTVlYzA3M2QwOSIsIm5ld191c2VyIjpmYWxzZSwiZmlyc3RfbmFtZSI6IlRlc3QiLCJsYXN0X25hbWUiOiJ0ZXN0IiwicHJvZmlsZV9waWN0dXJlIjoiNDY0NjQ3NzgtNWYyNy00YTdiLTkwYjMtOWZiZDMzNzc2NGI5L3Byb2ZpbGVfcGljLzc3ZGU3MjY3LWY3ODctNGE0Yy04OTI0LTJmMjk3Y2NlZWNkZC5qcGciLCJyb2xlX2lkIjo0LCJtb2JpbGVfbm8iOiIwNTYxMjM0NTY3IiwiaXNfZW1haWxfdmVyaWZpZWQiOjEsImVtYWlsIjoidGVzdDFAdGVzdC5jb20iLCJqdGkiOiI5MjUxYTYyOS05ZGM0LTRiMDYtYTE3ZS04ZjlmZDJhZmU5MDEiLCJpYXQiOjE2MzEyNzg2MzEsImV4cCI6MTYzMTMyMTgzMSwiYXVkIjoic3RhZ2luZy1lbnYtbmxiLTNhODg1ZDhmYWJlNGE0MjIuZWxiLmFwLXNvdXRoLTEuYW1hem9uYXdzLmNvbSIsImlzcyI6InZkZXppX2lkZW50aXR5X3Byb3ZpZGVyIn0.RS893GHooNZPaxJzFDR2cSq9yH3jD8Gg9s10iMrnRPk'
      }
    };

    await axios(config)
      .then(function (response) {
        console.log(JSON.stringify(response.data));
        resp = response.data;
      })
      .catch(function (error) {
        console.log(error);
      });
    return resp;
  }

  async getOrderfromSalasa(pOrderId) {
    let resp;
    var config = {
      method: 'get',
      url: `https://staging-salasa-api-internal.eunimart.com/api/v2/order_management/order/get?order_id=${pOrderId}&account_id=ad710796-f862-41f6-8c50-eb15ec073d09`,
      headers: {
        'Authorization': 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoiMjFmYTI3YjctM2Y1Ni00MzJmLWIwNzItYWU4MmU1OGM4YWRlIiwiYWNjb3VudF9pZCI6ImFkNzEwNzk2LWY4NjItNDFmNi04YzUwLWViMTVlYzA3M2QwOSIsIm5ld191c2VyIjpmYWxzZSwiZmlyc3RfbmFtZSI6IlRlc3QiLCJsYXN0X25hbWUiOiJ0ZXN0IiwicHJvZmlsZV9waWN0dXJlIjoiNDY0NjQ3NzgtNWYyNy00YTdiLTkwYjMtOWZiZDMzNzc2NGI5L3Byb2ZpbGVfcGljLzc3ZGU3MjY3LWY3ODctNGE0Yy04OTI0LTJmMjk3Y2NlZWNkZC5qcGciLCJyb2xlX2lkIjo0LCJtb2JpbGVfbm8iOiIwNTYxMjM0NTY3IiwiaXNfZW1haWxfdmVyaWZpZWQiOjEsImVtYWlsIjoidGVzdDFAdGVzdC5jb20iLCJqdGkiOiI5MjUxYTYyOS05ZGM0LTRiMDYtYTE3ZS04ZjlmZDJhZmU5MDEiLCJpYXQiOjE2MzEyNzg2MzEsImV4cCI6MTYzMTMyMTgzMSwiYXVkIjoic3RhZ2luZy1lbnYtbmxiLTNhODg1ZDhmYWJlNGE0MjIuZWxiLmFwLXNvdXRoLTEuYW1hem9uYXdzLmNvbSIsImlzcyI6InZkZXppX2lkZW50aXR5X3Byb3ZpZGVyIn0.RS893GHooNZPaxJzFDR2cSq9yH3jD8Gg9s10iMrnRPk'
      }
    };

    await axios(config)
      .then(function (response) {
        console.log(JSON.stringify(response.data));
        resp = response.data;
      })
      .catch(function (error) {
        console.log(error);
      });
    return resp;
  }


  async createReturn(pPayload, pReturnId) {
    let resp;

    var data = JSON.stringify({
      "data": {
        "account_id": "ad710796-f862-41f6-8c50-eb15ec073d09",
        "return_type": "return",
        "channel_type": "offline",
        "order_id": pPayload.data.order_id,
        "pickup_address": {
          "pickup_company_name": "sadasd",
          "pickup_name": pPayload.data.receiver_name,
          "pickup_mobile_no": pPayload.data.receiver_mobile_no,
          "pickup_email_id": pPayload.data.receiver_email_id,
          "pickup_address_1": pPayload.data.receiver_address_1,
          "pickup_address_2": pPayload.data.receiver_address_2,
          "pickup_address_3": pPayload.data.receiver_address_3,
          "pickup_pincode": pPayload.data.receiver_pincode,
          "pickup_district": pPayload.data.receiver_district,
          "pickup_state": "",
          "pickup_city": pPayload.data.receiver_city,
          "pickup_country": pPayload.data.receiver_country
        },
        "receiver_address": {
          "receiver_company_name": "",
          "receiver_name": pPayload.data.receiver_name,
          "receiver_mobile_no": pPayload.data.receiver_mobile_no,
          "receiver_email_id": pPayload.data.receiver_email_id,
          "receiver_address_1": pPayload.data.receiver_address_1,
          "receiver_address_2": pPayload.data.receiver_address_2,
          "receiver_address_3": pPayload.data.receiver_address_3,
          "receiver_pincode": pPayload.data.receiver_pincode,
          "receiver_district": pPayload.data.receiver_district,
          "receiver_state": "",
          "receiver_address_type": "warehouse",
          "receiver_city": pPayload.data.receiver_city,
          "receiver_country": pPayload.data.receiver_country
        },
        "billing_address": pPayload.data.billing_address,
        "payment_details": {
          "payment_method": "prepaid"
        },
        "geo_location_details": {
          "city_id": 14,
          "country_id": 1,
          "district_id": 3
        },
        "client_code": "TEST1"
      }
    });

    var config = {
      method: 'post',
      url: 'https://staging-salasa-api-internal.eunimart.com/api/v2/order_management/return/create?account_id=ad710796-f862-41f6-8c50-eb15ec073d09',
      headers: {
        'Authorization': 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoiMjFmYTI3YjctM2Y1Ni00MzJmLWIwNzItYWU4MmU1OGM4YWRlIiwiYWNjb3VudF9pZCI6ImFkNzEwNzk2LWY4NjItNDFmNi04YzUwLWViMTVlYzA3M2QwOSIsIm5ld191c2VyIjpmYWxzZSwiZmlyc3RfbmFtZSI6IlRlc3QiLCJsYXN0X25hbWUiOiJ0ZXN0IiwicHJvZmlsZV9waWN0dXJlIjoiNDY0NjQ3NzgtNWYyNy00YTdiLTkwYjMtOWZiZDMzNzc2NGI5L3Byb2ZpbGVfcGljLzc3ZGU3MjY3LWY3ODctNGE0Yy04OTI0LTJmMjk3Y2NlZWNkZC5qcGciLCJyb2xlX2lkIjo0LCJtb2JpbGVfbm8iOiIwNTYxMjM0NTY3IiwiaXNfZW1haWxfdmVyaWZpZWQiOjEsImVtYWlsIjoidGVzdDFAdGVzdC5jb20iLCJqdGkiOiI5MjUxYTYyOS05ZGM0LTRiMDYtYTE3ZS04ZjlmZDJhZmU5MDEiLCJpYXQiOjE2MzEyNzg2MzEsImV4cCI6MTYzMTMyMTgzMSwiYXVkIjoic3RhZ2luZy1lbnYtbmxiLTNhODg1ZDhmYWJlNGE0MjIuZWxiLmFwLXNvdXRoLTEuYW1hem9uYXdzLmNvbSIsImlzcyI6InZkZXppX2lkZW50aXR5X3Byb3ZpZGVyIn0.RS893GHooNZPaxJzFDR2cSq9yH3jD8Gg9s10iMrnRPk',
        'Content-Type': 'application/json'
      },
      data: data
    };

    await axios(config)
      .then(function (response) {
        console.log(JSON.stringify(response.data));
        resp = response.data;
      })
      .catch(function (error) {
        console.log(error);
      });

    return resp;

  }

  async addItemsToReturn(pItem, pReturnId) {

    var resp;
    var payload =[];
    var temp = {
      "account_id": "ad710796-f862-41f6-8c50-eb15ec073d09",
      "return_id": pReturnId,
      "sku_id": pItem.sku_id,
      "title": pItem.title,
      "item_quantity": pItem.item_quantity,
      "return_quantity": pItem.item_quantity,
      "return_reason_text": "Product damaged, but shipping box OK",
      "channel_type": "offline",
      "return_line_id": pItem.order_line_id,
      "item_amount": pItem.item_amount,
      "approve_status": 1
    }
    payload.push(temp);
    var data = JSON.stringify({
      "data": temp
    });

    var config = {
      method: 'post',
      url: 'https://staging-salasa-api-internal.eunimart.com/api/v2/order_management/return_item/create?account_id=ad710796-f862-41f6-8c50-eb15ec073d09',
      headers: {
        'Authorization': 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoiMjFmYTI3YjctM2Y1Ni00MzJmLWIwNzItYWU4MmU1OGM4YWRlIiwiYWNjb3VudF9pZCI6ImFkNzEwNzk2LWY4NjItNDFmNi04YzUwLWViMTVlYzA3M2QwOSIsIm5ld191c2VyIjpmYWxzZSwiZmlyc3RfbmFtZSI6IlRlc3QiLCJsYXN0X25hbWUiOiJ0ZXN0IiwicHJvZmlsZV9waWN0dXJlIjoiNDY0NjQ3NzgtNWYyNy00YTdiLTkwYjMtOWZiZDMzNzc2NGI5L3Byb2ZpbGVfcGljLzc3ZGU3MjY3LWY3ODctNGE0Yy04OTI0LTJmMjk3Y2NlZWNkZC5qcGciLCJyb2xlX2lkIjo0LCJtb2JpbGVfbm8iOiIwNTYxMjM0NTY3IiwiaXNfZW1haWxfdmVyaWZpZWQiOjEsImVtYWlsIjoidGVzdDFAdGVzdC5jb20iLCJqdGkiOiI5MjUxYTYyOS05ZGM0LTRiMDYtYTE3ZS04ZjlmZDJhZmU5MDEiLCJpYXQiOjE2MzEyNzg2MzEsImV4cCI6MTYzMTMyMTgzMSwiYXVkIjoic3RhZ2luZy1lbnYtbmxiLTNhODg1ZDhmYWJlNGE0MjIuZWxiLmFwLXNvdXRoLTEuYW1hem9uYXdzLmNvbSIsImlzcyI6InZkZXppX2lkZW50aXR5X3Byb3ZpZGVyIn0.RS893GHooNZPaxJzFDR2cSq9yH3jD8Gg9s10iMrnRPk',
        'Content-Type': 'application/json'
      },
      data: data
    };

    await axios(config)
      .then(function (response) {
        console.log(JSON.stringify(response.data));
        resp = response.data;
      })
      .catch(function (error) {
        console.log(error);
      });


    return resp;
  }

  async updateReturn(pReturnId) {
    let resp;
    var data = JSON.stringify({
      "data": {
        "account_id": "ad710796-f862-41f6-8c50-eb15ec073d09",
        "return_id": pReturnId,
        "step_no": 3
      }
    });

    var config = {
      method: 'post',
      url: 'https://staging-salasa-api-internal.eunimart.com/api/v2/order_management/return/update?account_id=ad710796-f862-41f6-8c50-eb15ec073d09',
      headers: {
        'Authorization': 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoiMjFmYTI3YjctM2Y1Ni00MzJmLWIwNzItYWU4MmU1OGM4YWRlIiwiYWNjb3VudF9pZCI6ImFkNzEwNzk2LWY4NjItNDFmNi04YzUwLWViMTVlYzA3M2QwOSIsIm5ld191c2VyIjpmYWxzZSwiZmlyc3RfbmFtZSI6IlRlc3QiLCJsYXN0X25hbWUiOiJ0ZXN0IiwicHJvZmlsZV9waWN0dXJlIjoiNDY0NjQ3NzgtNWYyNy00YTdiLTkwYjMtOWZiZDMzNzc2NGI5L3Byb2ZpbGVfcGljLzc3ZGU3MjY3LWY3ODctNGE0Yy04OTI0LTJmMjk3Y2NlZWNkZC5qcGciLCJyb2xlX2lkIjo0LCJtb2JpbGVfbm8iOiIwNTYxMjM0NTY3IiwiaXNfZW1haWxfdmVyaWZpZWQiOjEsImVtYWlsIjoidGVzdDFAdGVzdC5jb20iLCJqdGkiOiI5MjUxYTYyOS05ZGM0LTRiMDYtYTE3ZS04ZjlmZDJhZmU5MDEiLCJpYXQiOjE2MzEyNzg2MzEsImV4cCI6MTYzMTMyMTgzMSwiYXVkIjoic3RhZ2luZy1lbnYtbmxiLTNhODg1ZDhmYWJlNGE0MjIuZWxiLmFwLXNvdXRoLTEuYW1hem9uYXdzLmNvbSIsImlzcyI6InZkZXppX2lkZW50aXR5X3Byb3ZpZGVyIn0.RS893GHooNZPaxJzFDR2cSq9yH3jD8Gg9s10iMrnRPk',
        'Content-Type': 'application/json'
      },
      data: data
    };

    await axios(config)
      .then(function (response) {
        console.log(JSON.stringify(response.data));
        resp = response.data;
      })
      .catch(function (error) {
        console.log(error);
      });

  }

  async completeReturn(pReturnId) {
    let resp;
    var data = JSON.stringify({
      "data": {
        "account_id": "ad710796-f862-41f6-8c50-eb15ec073d09",
        "return_id": pReturnId
      }
    });

    var config = {
      method: 'post',
      url: 'https://staging-salasa-api-internal.eunimart.com/api/v2/order_management/return/final_submit?account_id=ad710796-f862-41f6-8c50-eb15ec073d09',
      headers: {
        'Authorization': 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoiMjFmYTI3YjctM2Y1Ni00MzJmLWIwNzItYWU4MmU1OGM4YWRlIiwiYWNjb3VudF9pZCI6ImFkNzEwNzk2LWY4NjItNDFmNi04YzUwLWViMTVlYzA3M2QwOSIsIm5ld191c2VyIjpmYWxzZSwiZmlyc3RfbmFtZSI6IlRlc3QiLCJsYXN0X25hbWUiOiJ0ZXN0IiwicHJvZmlsZV9waWN0dXJlIjoiNDY0NjQ3NzgtNWYyNy00YTdiLTkwYjMtOWZiZDMzNzc2NGI5L3Byb2ZpbGVfcGljLzc3ZGU3MjY3LWY3ODctNGE0Yy04OTI0LTJmMjk3Y2NlZWNkZC5qcGciLCJyb2xlX2lkIjo0LCJtb2JpbGVfbm8iOiIwNTYxMjM0NTY3IiwiaXNfZW1haWxfdmVyaWZpZWQiOjEsImVtYWlsIjoidGVzdDFAdGVzdC5jb20iLCJqdGkiOiI5MjUxYTYyOS05ZGM0LTRiMDYtYTE3ZS04ZjlmZDJhZmU5MDEiLCJpYXQiOjE2MzEyNzg2MzEsImV4cCI6MTYzMTMyMTgzMSwiYXVkIjoic3RhZ2luZy1lbnYtbmxiLTNhODg1ZDhmYWJlNGE0MjIuZWxiLmFwLXNvdXRoLTEuYW1hem9uYXdzLmNvbSIsImlzcyI6InZkZXppX2lkZW50aXR5X3Byb3ZpZGVyIn0.RS893GHooNZPaxJzFDR2cSq9yH3jD8Gg9s10iMrnRPk',
        'Content-Type': 'application/json'
      },
      data: data
    };

    await axios(config)
      .then(function (response) {
        console.log(JSON.stringify(response.data));
        resp = response.data;
      })
      .catch(function (error) {
        console.log(error);
      });
    return resp;
  }


  async generatePayload(pPayload) {
    var salasaPayload = {
      "data": {
        "account_id": `${this.account_id}`,
        "geo_location_details": {
          "country_id": 1,
          "city_id": 4,
          "district_id": 6
        },
        "receiver_address": {
          "receiver_email_id": "bhavin07@ymail.com",
          "receiver_name": "bhavin",
          "receiver_address_1": "101 mainstreet",
          "receiver_address_2": "",
          "receiver_address_3": "",
          "receiver_state": "",
          "receiver_pincode": "",
          "receiver_company_name": "bhavin",
          "receiver_district": "Al Faisaliyah",
          "receiver_mobile_no": "9029308552",
          "receiver_city": "Dammam",
          "receiver_country": "Saudi Arabia"
        },
        "billing_address": {
          "billing_email_id": "bhavin07@ymail.com",
          "billing_company_name": "bhavin",
          "billing_name": "bhavin",
          "billing_address_1": "101 mainstreet",
          "billing_address_2": "",
          "billing_address_3": "",
          "billing_district": "Al Faisaliyah",
          "billing_state": "",
          "billing_pincode": "",
          "billing_mobile_no": "9029308552",
          "billing_city": "Dammam",
          "billing_country": "Saudi Arabia"
        },
        "channel_type": "offline",
         "marketplace_order_id": "23213",
        "vas_options": "no",
        "payment_details": {
          "payment_method": "prepaid"
        },
        "order_amount": {
          "price": 300,
          "currency_code": "SAR"
        },
        "shipping_type": "salasa_shipping",
        "package_details": {
          "package_weight": 0,
          "package_length": 0,
          "package_width": 0,
          "package_height": 0
        },
        "shipment_service_level": "EXP",
        "client_code": "TEST1"
      }
    };


    return salasaPayload;
  }


  async sendOrderToSalasa(pPayload) {
    console.log(`[orderConnector] Inside sendOrderToSalasa`);
    var self = this;
    let respPayload;

    try {
      const salasaPayload = await this.generatePayload(pPayload);
      const accountId = `${this.account_id}`;
      const token = `${this.token}`;
      const salasaHostname = `${this.salasaHostname}`;
      const occOrderId = pPayload.id;
      console.log(`[orderConnector] Sending OCC Order ${occOrderId} to Salasa`);
      
    
      var data = JSON.stringify({
        "data": {
          "account_id": accountId,
          "geo_location_details": {
            "country_id": 1,
            "city_id": 4,
            "district_id": 6
          },
          "receiver_address": {
            "receiver_email_id": pPayload.profile ? pPayload.profile.login :pPayload.shippingGroups[0].shippingAddress.email,
            "receiver_name": pPayload.shippingGroups[0].shippingAddress.firstName + ' ' + pPayload.shippingGroups[0].shippingAddress.lastName,
            "receiver_address_1": pPayload.shippingGroups[0].shippingAddress.address1 ? pPayload.shippingGroups[0].shippingAddress.address1 : '',
            "receiver_address_2": pPayload.shippingGroups[0].shippingAddress.address2 ? pPayload.shippingGroups[0].shippingAddress.address2: '',
            "receiver_address_3": pPayload.shippingGroups[0].shippingAddress.address3 ? pPayload.shippingGroups[0].shippingAddress.address3 : '',
            "receiver_state": "",
            "receiver_pincode": pPayload.shippingGroups[0].postalCode,
            "receiver_company_name":  pPayload.shippingGroups[0].companyName? pPayload.shippingGroups[0].shippingAddress.companyName :  '',
            "receiver_district": "Al Faisaliyah",
            "receiver_mobile_no":pPayload.shippingGroups[0].shippingAddress.phoneNumber,
            "receiver_city": pPayload.shippingGroups[0].shippingAddress.city,
            "receiver_country": "Saudi Arabia"
          },
          "billing_address": {
            "billing_email_id": pPayload.paymentGroups[0].billingAddress.email,
            "billing_company_name": "",
            "billing_name": pPayload.paymentGroups[0].billingAddress.firstName + '' + pPayload.paymentGroups[0].billingAddress.lastName,
            "billing_address_1": pPayload.paymentGroups[0].billingAddress.address1 ? pPayload.paymentGroups[0].billingAddress.address1 : '',
            "billing_address_2": pPayload.paymentGroups[0].billingAddress.address2 ? pPayload.paymentGroups[0].billingAddress.address2 : '',
            "billing_address_3": pPayload.paymentGroups[0].billingAddress.address3 ? pPayload.paymentGroups[0].billingAddress.address3 : '',
            "billing_district": "Al Faisaliyah",
            "billing_state": "",
            "billing_pincode": "",
            "billing_mobile_no": pPayload.paymentGroups[0].billingAddress.phoneNumber,
            "billing_city": pPayload.paymentGroups[0].billingAddress.city,
            "billing_country": "Saudi Arabia"
          },
          "channel_type": "offline",
          "marketplace_order_id": pPayload.id,
          "vas_options": "no",
          "payment_details": {
            "payment_method": "prepaid"
          },
          "order_amount": {
            "price": pPayload.priceInfo.total,
            "currency_code": "SAR"
          },
          "shipping_type": "salasa_shipping",
          "package_details": {
            "package_weight": 0,
            "package_length": 0,
            "package_width": 0,
            "package_height": 0
          },
          "shipment_service_level": "EXP",
          "client_code": "222"
        }
      });

      var config = {
        method: 'post',
        url: `${salasaHostname}/api/v2/order_management/order/create?account_id=${accountId}`,
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        data: data
      };

     await axios(config)
        .then(async function (response) {
          console.log(JSON.stringify(response.data));
          if (response.data) {
            const resp = response.data;
            const orderId = resp.data.order_id;
            console.log("Order Created in Salasa with id ::: " + orderId);
             respPayload = orderId;
            console.log("Updating items for Order ::: " + orderId);
            const items =await self.addItemsToOrder(orderId,pPayload.commerceItems);
            const Order = await self.updateOrder(occOrderId, orderId,"salasa");
            console.log(Order);
           
            var data = JSON.stringify({
              "data": {
                "account_id": accountId,
                "order_id": orderId
              }
            });

            var config = {
              method: 'post',
              url: `${salasaHostname}/api/v2/order_management/order/final_submit?account_id=${accountId}`,
              headers: {
                'Authorization': `Bearer ${token}`,
                'Content-Type': 'application/json'
              },
              data: data
            };
          await  axios(config)
              .then(function (response) {
                console.log(JSON.stringify(response.data));
                return response.data;
              })
              .catch(function (error) {
                console.log(error);
              });
          }
        })
        .catch(function (error) {
          console.log(error);
        });

      return respPayload;
    } catch (e) {
      console.log(`Cannot update order :  ${e}`);
      throw e;
    }
  }

  async addItemsToOrder(pOccOrderId, pPayload) {

    console.log("Inside  ::: " + pOccOrderId);
    console.log("Adding Items  ::: " + pPayload);
    console.log(this);
    let commerceItems = pPayload;
    for (var i = 0; i < commerceItems.length; i++) {
      var data = JSON.stringify({
        "data": {
          "account_id": this.account_id,
          "order_id": pOccOrderId,
          "sku_id": commerceItems[i].catalogRefId,
          "title": commerceItems[i].productDisplayName,
          "item_quantity":  commerceItems[i].quantity,
          "channel_type": "offline",
          "fulfill_inventory_bucket": "in_available",
          "item_amount":  commerceItems[i].priceInfo.amount
        }
      });

      var config = {
        method: 'post',
        url: `${this.salasaHostname}/api/v2/order_management/order_item/create?account_id=${this.account_id}`,
        headers: {
          'Authorization': `Bearer ${this.token}`,
          'Content-Type': 'application/json'
        },
        data: data
      };

      await axios(config)
        .then(function (response) {
          console.log(JSON.stringify(response.data));
        })
        .catch(function (error) {
          console.log(error);
        });
    }
  }


  async updateReturnOrder(pOccOrderId, pIntegrationReturnId,) {
    const token = await this.getToken();
    // var orderId = pPayload.id;
    try {
      const orders = await request({
        headers: {
          Authorization: `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        url: `${this.host_name}/ccadmin/v1/orders/${pOccOrderId}`,
        method: 'PUT',
        json: true,
        body: {
          state: "PENDING_CUSTOMER_RETURN",
          return_order_id : pIntegrationReturnId
        }
      });
      console.log(
        ` [Order] Sending back HTTP 200: ${JSON.stringify(orders,
          null,
          2
        )}`);

      return orders;
    } catch (e) {
      console.log(`Cannot update order :  ${e}`);
      throw e;
    }
  }

  async getOrder(pOccOrderId) {
    let order ;
    const token = await this.getToken();
    // var orderId = pPayload.id;
    try {
      var axios = require('axios');

var config = {
  method: 'get',
  url: `${this.host_name}/ccadmin/v1/orders/${pOccOrderId}`,
  headers: { 
    'Accept': 'application/json', 
    'Content-Type': 'application/json', 
    Authorization: `Bearer ${token}`,
    }
};

await axios(config)
.then(function (response) {
  console.log(JSON.stringify(response.data));
  order = response.data; 
})
.catch(function (error) {
  console.log(error);
});



      return order;
    } catch (e) {
      console.log(`Cannot update order :  ${e}`);
      throw e;
    }
  }


  async updateOrder(pOccOrderId, pIntegrationOrderId,erpName) {
    const token = await this.getToken();
    // var orderId = pPayload.id;
    try {
      const orders = await request({
        headers: {
          Authorization: `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        url: `${this.host_name}/ccadmin/v1/orders/${pOccOrderId}`,
        method: 'PUT',
        json: true,
        body: {
          state: "PROCESSING",
          erp_orderId: pIntegrationOrderId,
          erp_name : erpName
        }
      });
      console.log(
        ` [Order] Sending back HTTP 200: ${JSON.stringify(orders,
          null,
          2
        )}`);

      return orders;
    } catch (e) {
      console.log(`Cannot update order :  ${e}`);
      throw e;
    }
  }


  /*
  This method would return access token based on the requesting enviroment .

  */
 async getToken(){
   let accessToken = '';
  var axios = require('axios');
  var qs = require('qs');
  var data = qs.stringify({
    'grant_type': 'client_credentials' 
  });
  var config = {
    method: 'post',
    url: 'https://p1550825c1dev-admin.occa.ocs.oraclecloud.com/ccadmin/v1/login/',
    headers: { 
      'Content-Type': 'application/x-www-form-urlencoded', 
      'Authorization': 'Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiI3NDM4NTNlYS05YmNkLTQ3YmYtYTYzYS0zZTc2YzBjZmZlNDYiLCJpc3MiOiJhcHBsaWNhdGlvbkF1dGgiLCJleHAiOjE2NDEzNTcyMTMsImlhdCI6MTYwOTgyMTIxM30=.jx0S6pNwldx+Ahl5bB0r+qooYT/2lbspD1ovvTXsIx8=', 
      'Cookie': 'ak_bmsc=01B35EB7AF72D95668C4666E1B4D549C~000000000000000000000000000000~YAAQoUU5F+iWFFh8AQAAxnLtiQ3grCMxQ045uFtXYNSnfdsOWtSyoyI/pXRw+rqRs05babkKNa1mj0V1eavMIppjKVNfNKns4Q64QfbP/twR8e1/9hK6LWquLuGbT3Q86D71Lz3eYjFUap8SJTkCDkZiXDU+3GOpyCEbwVaG5JRyxAo8EI3QL3D8IM29mvnKnTtB7IBwTiR9kTJ3pvgSh4jZvs5Y7O5Ll+3Q2c7nfBqov2rS77WrR9magUG2dmSZ/MRZqnAQUDdNuHpIuZ1o+/b18JYrg6GiuanqqoIag7jDNTY2Zcs3wAMvGHCnOSEK8DsqYdc+U7Cj2pLHq3eVNO8iGYgm8NwfnMZ6LMhQdMGE/xi+UwIAsstiDC0KwzHNPy+sm447fInAVA==; bm_sv=6CAF81BC9674CCC34D1EB4081EAD19D9~UztbDLLjY/d1m8hNeBt+CuUzFfWwY0fehl75Sy+3crPY6jUS2xbpNX+Q7CcomKfZsB1rxqe+r9oPwYgIeodSdkp4ZeFpo7cZNP93dSAN6vmWXsyHf5TvdyyIRfjOfs39vFTnTHeiBkWUoq0O17cuMAL91zqoA2Gou8MMppA5DpQ=; JSESSIONID=T6qKV4JrenxWoXLZXSRGiJdlHxS3vnGXnWSVe8JV9MXj7X_wQql6!-18598221; ccadminroute=e78be2c81529c5061a215c58dfd92472'
    },
    data : data
  };
  
  await axios(config)
  .then(function (response) {
    console.log(JSON.stringify(response.data));
    accessToken =response.data.access_token;
  })
  .catch(function (error) {
    console.log(error);
  });
  return accessToken;

 }
  async retrieveToken() {

    let loginResponse;
    try {
      loginResponse = await request({
        headers: {
          Authorization: `Bearer ${this.api_key}`,
          'Content-Type': 'application/x-www-form-urlencoded'
        },
        url: `${this.host_name}/ccadminui/v1/login`,
        method: 'POST',
        body: querystring.stringify({
          grant_type: 'client_credentials'
        }),
        json: true
      });
    } catch (e) {
      console.log(`Cannot get credentials. ${e}`);
      throw e;
    }
    return loginResponse.access_token;
  }


}

module.exports = salasa;