const querystring = require("querystring");
const parser = require('fast-xml-parser');
const he = require('he');
const request = require('request');

class miscReciept {
  constructor(options) {
    this.host_name = options.admin_url;
    this.api_key = options.api_key;
  }

 


  async sendMiscReciept(pPayload) {

    console.log("Inside Send To Fusion");

    const soapRequest = require('easy-soap-request');
    const fs = require('fs');
    let orderResp;
    let order = await this.getOCCOrder(pPayload.orderId);
    console.log(order);
    var itemXML = '';
    let erp_name =  order.erp_name;

    let ecommOrder;

    if(erp_name === 'fusion') {
      console.log("No reciept is send for OUD Fusion orders");
      return "No reciept is send for OUD Fusion orders";
    }
    //let erpOrderType = order
    if(order.paymentGroups[0].paymentMethod === 'onlinePaymentGroup') {
      ecommOrder = 'Online Payment';
    }else {
      ecommOrder = 'Cash on Delivery';
    }
    for(var i=0 ;i<pPayload.returnItemArray.length ;i++) {

      const payload = `
      <typ:interfaceRows>
         <stag:TransactionInterfaceId>222</stag:TransactionInterfaceId>
         <stag:TransactionHeaderId>222</stag:TransactionHeaderId>
         <stag:SourceCode>777</stag:SourceCode>
         <stag:SourceLineId>2000</stag:SourceLineId>
         <stag:SourceHeaderId>1000</stag:SourceHeaderId>
         <stag:ProcessCode>1</stag:ProcessCode>
         <stag:SubinventoryCode>NOR</stag:SubinventoryCode>
         <stag:TransactionMode>3</stag:TransactionMode>
         <stag:OrganizationId>300000002016323</stag:OrganizationId>
         <stag:TransactionQuantity unitCode="zzy">${pPayload.returnItemArray[i].quantityReturned}</stag:TransactionQuantity>
         <stag:TransactionUOM>zzy</stag:TransactionUOM>
         <stag:TransactionDate>${new Date().toJSON().slice(0,10)}T00:00:00.000+00:00</stag:TransactionDate>
         <stag:TransactionSourceTypeId>13</stag:TransactionSourceTypeId>
         <stag:TransactionActionId>42</stag:TransactionActionId>
         <stag:TransactionTypeId>42</stag:TransactionTypeId>
         <stag:DistributionAccountId>11000</stag:DistributionAccountId>
         <stag:LineItemNumber>${i+1}</stag:LineItemNumber>
         <stag:ShipmentNumber>${order.id}_${pPayload.returnItemArray[i].itemId}</stag:ShipmentNumber>
         <stag:ItemNumber>${pPayload.returnItemArray[i].itemId}</stag:ItemNumber>
         <stag:LocatorName>1-BA-16-10-30</stag:LocatorName>
         <stag:UseCurrentCost>Y</stag:UseCurrentCost>
         <stag:Attribute7>${ecommOrder}</stag:Attribute7>
         <!--<stag:TaskId>111</stag:TaskId>
         <stag:ProjectId>112</stag:ProjectId>-->
         <stag:Attribute3>${order.shippingGroups[0].shippingAddress.firstName} </stag:Attribute3>
         <!--Optional:-->
         <stag:Attribute4>${order.shippingGroups[0].shippingAddress.phoneNumber}</stag:Attribute4>
         <!--Optional:-->
         <stag:Attribute5>${order.shippingGroups[0].shippingAddress.address1}</stag:Attribute5>
         <!--Optional:-->
         <stag:Attribute6>${order.id}</stag:Attribute6>
         <stag:StagedInventoryTransactionLot>
            <!--Optional:-->
            <stag:TransactionInterfaceId>222</stag:TransactionInterfaceId>
            <!--Optional:-->
            <stag:LotNumber>Lot-01</stag:LotNumber>
            <!--Optional:-->
            <stag:TransactionQuantity unitCode="zzy">${pPayload.returnItemArray[i].quantityReturned}</stag:TransactionQuantity>
            <!--Optional:-->
         </stag:StagedInventoryTransactionLot>
      </typ:interfaceRows>
      <typ:headerId>222</typ:headerId>
      <typ:validationLevel>1</typ:validationLevel>
      <typ:tableType>1</typ:tableType>`;

      itemXML =itemXML +payload;

    

    console.log(itemXML);

    // example data
    const url = 'https://egrc-test.fa.us2.oraclecloud.com/fscmService/TransactionManagerServiceV2';
    const sampleHeaders = {
      'user-agent': 'sampleTest',
      'Authorization': 'Basic YW1yX21hbnNvdXJAcmF5YWlzLmNvbTpSYXlhMTIzNA==',
      'Content-Type': 'text/xml;charset=UTF-8',
      'soapAction': 'http://xmlns.oracle.com/apps/scm/fom/importOrders/orderImportService/createOrders',
    };


    const xml = `<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:typ="http://xmlns.oracle.com/apps/scm/inventory/materialTransactions/pendingTransactions/transactionManagerServiceV2/types/" xmlns:stag="http://xmlns.oracle.com/apps/scm/inventory/materialTransactions/pendingTransactions/stagedInventoryTransactionServiceV2/">
    <soapenv:Header/>
    <soapenv:Body>
    <typ:insertAndProcessInterfaceRows>
    ${itemXML}
    </typ:insertAndProcessInterfaceRows>
    </soapenv:Body>
 </soapenv:Envelope>`;

    
    // usage of module


    try {
      const {
        response
      } = await soapRequest({
        url: url,
        headers: sampleHeaders,
        xml: xml
      }); // Optional timeout parameter(milliseconds)
      const {
        headers,
        body,
        statusCode
      } = response;
      console.log("==================================");
      console.log(headers);
      console.log("==================================");

      var options = {
        attributeNamePrefix: "@_",
        attrNodeName: "attr", //default is 'false'
        textNodeName: "#text",
        ignoreAttributes: true,
        ignoreNameSpace: false,
        allowBooleanAttributes: false,
        parseNodeValue: true,
        parseAttributeValue: false,
        trimValues: true,
        cdataTagName: "__cdata", //default is 'false'
        cdataPositionChar: "\\c",
        parseTrueNumberOnly: false,
        arrayMode: false, //"strict"
        attrValueProcessor: (val, attrName) => he.decode(val, {
          isAttributeValue: true
        }), //default is a=>a
        tagValueProcessor: (val, tagName) => he.decode(val), //default is a=>a
        stopNodes: ["parse-me-as-string"]
      };
     
      if (parser.validate(body) === true) { //optional (it'll return an object in case it's not valid)
        var jsonObj = parser.parse(body, options);
        console.log(jsonObj);
        orderResp =jsonObj;
      } 
     
    } catch (e) {
      const {
        headers,
        body,
        statusCode
      } = e;
      console.log(statusCode);
      console.error(e);
    }

    const delay = ms => new Promise(resolve => setTimeout(resolve, ms));
    await delay(10000);
   
  //  await this.waitforme(5000);
  }

  return orderResp;

  }
  

  async waitforme(ms)  {
    return new Promise( resolve => { setTimeout(resolve, ms); });
  }

  async updateOrder(occOrderId, fusionOrderId) {
    const token = await this.retrieveToken();
    var orderState;
    var orderId = occOrderId;

    var axios = require('axios');
    var data = '';

    var config = {
      method: 'put',
      url: `${this.host_name}/ccadmin/v1/orders/${orderId}`,
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'X-CCAsset-Language': 'en',
        'Authorization': `Bearer ${token}`,
      },
      data: {
        erp_orderId: fusionOrderId.toString(),
        erp_name: "fusion",
        state: "PROCESSING",
      }
    };

    await axios(config)
      .then(function (response) {
        console.log(JSON.stringify(response.data));
      })
      .catch(function (error) {
        console.log(error);
      });



  }

  async returnDataOrder(occOrderId, fusionOrderId) {
    const token = await this.retrieveToken();
    var orderState;
    var orderId = occOrderId;

    var axios = require('axios');
    var data = '';

    var config = {
      method: 'put',
      url: `${this.host_name}/ccadmin/v1/orders/${orderId}`,
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'X-CCAsset-Language': 'en',
        'Authorization': `Bearer ${token}`,
      },
      data: {
        return_order_id: fusionOrderId.toString(),
        erp_name: "fusion",
        state : "PENDING_CUSTOMER_RETURN"
      }
    };

    await axios(config)
      .then(function (response) {
        console.log(JSON.stringify(response.data));
      })
      .catch(function (error) {
        console.log(error);
      });



  }


  async getOCCOrder(id) {
    const token = await this.retrieveToken();
    let orders ;
    try {
    

      var axios = require('axios');

      var config = {
        method: 'get',
        url: `${this.host_name}/ccadmin/v1/orders/${id}`,
        headers: {
          Authorization: `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      };
      
     await axios(config)
      .then(function (response) {
        console.log(JSON.stringify(response.data));
        orders = response.data;
      })
      .catch(function (error) {
        console.log(error);
      });
      

return orders;



    } catch (e) {
      console.log(`Cannot update order :  ${e}`);
      throw e;
    }
  }


  async getOrders(pPayload) {
    const token = await this.retrieveToken();
    var date = `date("${pPayload.date}")`;
    var state = "SUBMITTED";
    try {

      const orders = await request({
        headers: {
          Authorization: `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        url: `${this.host_name}/ccadmin/v1/orders?queryFormat=SCIM&q=state eq "PENDING_APPROVAL"`,
        method: 'GET',
        json: true
      });
      console.log(
        ` [Order] Sending back HTTP 200: ${JSON.stringify(orders,
          null,
          2
        )}`);

      return orders;
    } catch (e) {
      console.log(`Cannot update order :  ${e}`);
      throw e;
    }
  }

  /*
  This method would return access token based on the requesting enviroment .

  */
  async retrieveToken() {

    let loginResponse;

    var axios = require('axios');
    var qs = require('qs');
    var data = qs.stringify({
      'grant_type': 'client_credentials'
    });
    var config = {
      method: 'post',
      url: `${this.host_name}/ccadminui/v1/login`,
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'Authorization': `Bearer ${this.api_key}`,
      },
      data: data
    };

    await axios(config)
      .then(function (response) {
        loginResponse = response.data;
        //  console.log(JSON.stringify(response.data));
      })
      .catch(function (error) {
        console.log(error);
      });


    return loginResponse.access_token;

    /*try {
      loginResponse = await request({
        headers: {
          Authorization: `Bearer ${this.api_key}`,
          'Content-Type': 'application/x-www-form-urlencoded'
        },
        url: `${this.host_name}/ccadminui/v1/login`,
        method: 'POST',
        body: querystring.stringify({
          grant_type: 'client_credentials'
        }),
        json: true
      });
    } catch (e) {
      console.log(`Cannot get credentials. ${e}`);
      throw e;
    }
    return loginResponse.access_token;
    */
  }
}

module.exports = miscReciept;