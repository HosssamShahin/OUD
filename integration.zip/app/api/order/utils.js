
const querystring = require("querystring");
const request = require('request');
const axios = require('axios');

class utils {
  constructor(options) {
    this.host_name = options.admin_url;
    this.api_key = options.api_key;
    this.account_id = options.account_id;
    this.token = options.token;
    this.salasaHostname = options.salasaHostname;
  }


  async fulfillOrder(pOccOrderId) {
    const token = await this.retrieveToken();
    console.log(token);
    const order = await this.getOrder(pOccOrderId, token);
    console.log(order);
    let response;

    order.state = "NO_PENDING_ACTION";
    order.shippingGroups[0].state = "NO_PENDING_ACTION";
    order.paymentGroups[0].state = "SETTLED";

    console.log(JSON.stringify(order));
    // var orderId = pPayload.id;
    //const order= await this.getOrder(pOccOrderId);

    var axios = require('axios');
    var data = JSON.stringify(order);

    var config = {
      method: 'put',
      url: `${this.host_name}/ccadmin/v1/orders/${pOccOrderId}`,
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'X-CCAsset-Language': 'en',
        'Authorization': `Bearer ${token}`
      },
      data: data
    };

    await axios(config)
      .then(function (response) {
        console.log(JSON.stringify(response.data));
        response = response.data;
      })
      .catch(function (error) {
        console.log(error);
      });

    return response;
  }


  async getOrder(pOccOrderId, token) {
    // var orderId = pPayload.id;
    let orders;
    try {

      var axios = require('axios');

      var config = {
        method: 'get',
        url: `${this.host_name}/ccadmin/v1/orders/${pOccOrderId}`,
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        }
      };

      await axios(config)
        .then(function (response) {
          console.log(JSON.stringify(response.data));
          orders = response.data;
        })
        .catch(function (error) {
          console.log(error);
        });

      return orders;
    } catch (e) {
      console.log(`Cannot update order :  ${e}`);
      throw e;
    }
  }


  /*
  This method would return access token based on the requesting enviroment .

  */
  async retrieveToken() {

    let loginResponse;
    try {

      var axios = require('axios');
      var qs = require('qs');
      var data = qs.stringify({
        'grant_type': 'client_credentials'
      });
      var config = {
        method: 'post',
        url: `${this.host_name}/ccadminui/v1/login`,
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
          'Authorization': `Bearer ${this.api_key}`,
        },
        data: data
      };

      await axios(config)
        .then(function (response) {
          console.log(JSON.stringify(response.data));
          loginResponse = response.data.access_token;
        })
        .catch(function (error) {
          console.log(error);
        });

      return loginResponse;

    } catch (e) {
      console.log(`Cannot get credentials. ${e}`);
      throw e;
    }
  }
}

module.exports = utils;